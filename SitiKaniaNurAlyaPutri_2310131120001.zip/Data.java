import java.time.LocalDate;

public class Data {
    private String nik;
    private String nama;
    private String pekerjaan;
    private LocalDate tanggalLahir;

    Data(String nik, String nama, String pekerjaan, LocalDate tanggalLahir) {
        this.nik = nik;
        this.nama = nama;
        this.pekerjaan = pekerjaan;
        this.tanggalLahir = tanggalLahir;
    }

    void show() {
        System.out.println("NIK : " + nik);
        System.out.println("Nama : " + nama);
        System.out.println("Pekerjaan : " + pekerjaan);
        System.out.println("Tanggal Lahir : " + tanggalLahir);
    }

    public LocalDate getTanggalLahir() {
        return tanggalLahir;
    }
}
