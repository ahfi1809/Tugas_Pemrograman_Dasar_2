import java.time.LocalDate;
import java.time.Period;

public class Pensiun extends Data {
    private int umur;
    private int tahunPensiun;

    Pensiun(String nik, String nama, String pekerjaan, LocalDate tanggalLahir) {
        super(nik, nama, pekerjaan, tanggalLahir);
        this.umur = hitungUmur();
        this.tahunPensiun = hitungTahunPensiun();
    }

    // Menghitung umur
    int hitungUmur() {
        LocalDate now = LocalDate.now();
        return Period.between(getTanggalLahir(), now).getYears();
    }

    // Menghitung tahun pensiun
    int hitungTahunPensiun() {
        int usiaPensiun = 60; 
        return getTanggalLahir().plusYears(usiaPensiun).getYear();
    }

    @Override
    void show() {
        super.show();
        System.out.println("Umur : " + umur);
        System.out.println("Tahun Pensiun : " + tahunPensiun);
    }
}