import java.time.LocalDate;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan NIK: ");
        String nik = scanner.nextLine();

        System.out.print("Masukkan Nama: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan Pekerjaan: ");
        String pekerjaan = scanner.nextLine();

        System.out.print("Masukkan Tanggal Lahir (yyyy-mm-dd): ");
        String tglLahirInput = scanner.nextLine();
        LocalDate tanggalLahir = LocalDate.parse(tglLahirInput);

        Pensiun dataPensiun = new Pensiun(nik, nama, pekerjaan, tanggalLahir);

        System.out.println("\n===== Data Karyawan =====");
        dataPensiun.show();
    }
}
