import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;

class Person {
    protected String nik;
    protected String nama;
    protected String tanggalLahir;

    public Person(String nik, String nama, String tanggalLahir) {
        this.nik = nik;
        this.nama = nama;
        this.tanggalLahir = tanggalLahir;
    }

    public int hitungUmur() {
        LocalDate lahir = LocalDate.parse(tanggalLahir);
        LocalDate sekarang = LocalDate.now();
        return Period.between(lahir, sekarang).getYears();
    }

    public void tampilkanInfo() {
        System.out.println("NIK : " + nik);
        System.out.println("Nama : " + nama);
        System.out.println("Tanggal Lahir : " + tanggalLahir);
        System.out.println("Umur : " + hitungUmur());
    }
}

class Employee extends Person {
    private String pekerjaan;

    public Employee(String nik, String nama, String tanggalLahir, String pekerjaan) {
        super(nik, nama, tanggalLahir);
        this.pekerjaan = pekerjaan;
    }

    public int hitungTahunPensiun() {
        int umurPensiun = 60;
        return LocalDate.now().getYear() + (umurPensiun - hitungUmur());
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Pekerjaan : " + pekerjaan);
        System.out.println("Tahun Pensiun : " + hitungTahunPensiun());
    }
}

public class Polimorfisme {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan NIK: ");
        String nik = scanner.nextLine();

        System.out.print("Masukkan Nama: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan Tanggal Lahir (YYYY-MM-DD): ");
        String tanggalLahir = scanner.nextLine();

        System.out.print("Masukkan Pekerjaan: ");
        String pekerjaan = scanner.nextLine();

        Person person = new Employee(nik, nama, tanggalLahir, pekerjaan);
        System.out.println("\nOutput");
        System.out.println("=========");
        person.tampilkanInfo();

        scanner.close();
    }
}
