import java.util.Scanner;

public class pensiun {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input data
        System.out.print("Masukkan NIK: ");
        String nik = input.nextLine();

        System.out.print("Masukkan Nama: ");
        String nama = input.nextLine();

        System.out.print("Masukkan Pekerjaan: ");
        String pekerjaan = input.nextLine();

        System.out.print("Masukkan Tanggal Lahir (dd-mm-yyyy): ");
        String tanggalLahir = input.nextLine();

        // Menghitung umur dan tahun pensiun
        System.out.print("Masukkan Tahun Sekarang: ");
        int tahunSekarang = input.nextInt();
        System.out.print("Masukkan Tahun Lahir: ");
        int tahunLahir = input.nextInt();
        
        int umur = tahunSekarang - tahunLahir;
        int tahunPensiun = tahunLahir + 60; // asumsi pensiun di umur 60 tahun

        // Output data
        System.out.println("\nOutput:");
        System.out.println("NIK            : " + nik);
        System.out.println("Nama           : " + nama);
        System.out.println("Pekerjaan      : " + pekerjaan);
        System.out.println("Tanggal Lahir  : " + tanggalLahir);
        System.out.println("Umur           : " + umur);
        System.out.println("Tahun Pensiun  : " + tahunPensiun);
    }
}